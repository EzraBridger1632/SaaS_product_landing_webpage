document.getElementById("getstarted_firstrow").addEventListener("click", function(){
    document.getElementById("sixthrow").scrollIntoView({
        behavior: "smooth"
    });
});

document.getElementById("getstarted_secondrow").addEventListener("click", function(){
    document.getElementById("sixthrow").scrollIntoView({
        behavior: "smooth"
    });
});

document.getElementById("viewcasestudy_secondrow").addEventListener("click", function(){
    document.getElementById("fourthrow").scrollIntoView({
        behavior: "smooth"
    });
});